package pkg;

public interface InputControl{
    public void onMouseClick(double x, double y);
}