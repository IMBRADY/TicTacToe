import java.util.ArrayList;

public class Intelligence
{
 private String[][] board;
 private int rowmove;
 private int colmove;
 private String side;
 private int movecount = 1;
 private EasyReader er = new EasyReader();
 private ArrayList<ArrayList<String[][]>> store;
 public Intelligence()
 {
 }
 public int getNextMoveRow()
 {
  return rowmove;
 }
 public int getNextMoveCol()
 {
  return colmove;
 }
 public Point decideMove(String [][] b, String input, String turn, Point move, boolean print)
 {
  Point decoyMove = new Point(5,5);
  String[][] pb = new String[3][3];
  ArrayList<Point>moves = new ArrayList<Point>();
  int max =-2;
  int min = 2;
  String iffy = turn;
  int test = 0;
  Point topMove = new Point(0,0,0);
   if(TicTacToe.isGameOver(b).equals("still"))
  {
	  if(input.equals(turn))
	  {
	   if(input.equals("o"))
	   {
		   test ++;
		   for(int i = 0; i < getCurrentMoves(b).size(); i++)
		   {
			decoyMove = getCurrentMoves(b).get(i);
			b[decoyMove.getRow()][decoyMove.getCol()] = turn;
			moves.add(decideMove(b,input,"x", decoyMove, print));
			b[decoyMove.getRow()][decoyMove.getCol()] = "-";
		   }
	   }
	   else
	   {
	     for(int i = 0; i < getCurrentMoves(b).size(); i++)
		   {
			decoyMove = getCurrentMoves(b).get(i);
			b[decoyMove.getRow()][decoyMove.getCol()] = turn;
			moves.add(decideMove(b,input,"o", decoyMove, print));
			b[decoyMove.getRow()][decoyMove.getCol()] = "-";
		   }
	   }
	   for(int i = 0; i < moves.size(); i++)
	   {
	    if(moves.get(i).getResult()>max)
	    {
	     topMove = moves.get(i);
		 max = moves.get(i).getResult();
   	    } 
	   }
	   if(print==true)
	   {
		   for(int i = 0; i < 3; i ++)
		   {
			for(int j = 0; j < 3; j++)
			{
			 System.out.print(b[i][j]);
			}
			System.out.println();
		   }
		   System.out.println("The game is not over");
		   System.out.println("The considered moves the ai has for " + iffy + " is " );
			for(int i = 0; i < moves.size(); i ++)
		   {
			System.out.println(moves.get(i).getRow() + " " + moves.get(i).getCol() + " " + moves.get(i).getResult());
		   }
		   System.out.println("The best move the ai has for " + iffy + " is " + topMove.getRow() + " " + topMove.getCol() + " " + topMove.getResult());
	   }
	  if(move.getRow()==5)
	  {
       return topMove;
	  }
	   return new Point(move.getRow(),move.getCol(),topMove.getResult());
	  }
	  else
	  {
	   for(int i = 0; i < getCurrentMoves(b).size(); i++)
	   {
		decoyMove = getCurrentMoves(b).get(i);
		b[decoyMove.getRow()][decoyMove.getCol()] = turn;
	    moves.add(decideMove(b,input,input, decoyMove, print));
		b[decoyMove.getRow()][decoyMove.getCol()] = "-";
       }
	   for(int i = 0; i < moves.size(); i++)
	   {
	    if(moves.get(i).getResult()<min)
	    {
	     topMove = moves.get(i);
		 min = moves.get(i).getResult();
   	    } 
	   }
	   if(print==true)
	   {
		   for(int i = 0; i < 3; i ++)
		   {
			for(int j = 0; j < 3; j++)
			{
			 System.out.print(b[i][j]);
			}
			System.out.println();
		   }
		   System.out.println("The game is not over");
		   System.out.println("The considered moves the ai has for " + iffy + " is " );
			for(int i = 0; i < moves.size(); i ++)
		   {
			System.out.println(moves.get(i).getRow() + " " + moves.get(i).getCol() + " " + moves.get(i).getResult());
		   }
		   System.out.println("The best move the ai has for " + iffy + " is " + topMove.getRow() + " " + topMove.getCol() + " " + topMove.getResult());
	   }
	   if(move.getRow()==5)
	   {
	    return topMove;
	   }
	   return new Point(move.getRow(),move.getCol(),topMove.getResult());
	  }
  }
  else
  {
   if(TicTacToe.isGameOver(b).equals("draw"))
   {
    return new Point(move.getRow(),move.getCol(),0);
   }
   else if(TicTacToe.isGameOver(b).equals(input))
   {
    return new Point(move.getRow(),move.getCol(),1);
   }
   else
   {
    return new Point(move.getRow(),move.getCol(),-1);
   }
  }
 }
 private ArrayList<Point> getCurrentMoves(String[][] boar)
 {
  ArrayList<Point> jacuzi  = new ArrayList<Point>();
  for(int row = 0; row < 3; row ++)
  {
   for(int col = 0; col < 3; col ++)
   {
    if(boar[row][col].equals("-"))
    {
     jacuzi.add(new Point(row,col));
	}
   }
  }
  return jacuzi;
 }
}
 