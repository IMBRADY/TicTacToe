public class Point
{
 private int r;
 private int c;
 private int result;
 public Point(int row, int col)
 {
  r = row;
  c = col;
 }
 public Point(int row, int col, int res)
 {
  r = row;
  c = col;
  result = res;
 }
 public int getRow()
 {
  return r;
 }
 public int getCol()
 {
  return c;
 }
 public int getResult()
 {
  return result;
 }
}
