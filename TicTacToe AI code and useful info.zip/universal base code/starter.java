import pkg.*;
import java.util.ArrayList;

public class starter implements InputControl, InputKeyControl {

	public static void main(String args[]) {
		// please leave following line alone, necessary for keyboard/mouse input
		KeyController kC = new KeyController(Canvas.getInstance(),new starter());
		MouseController mC = new MouseController(Canvas.getInstance(),new starter());
		String[][] test = new String[3][3];
		test[0][0] = "x";
		test[0][2] = "x";
		test[1][2] = "x";
		test[2][0] = "x";
		test[0][1] = "o";
		test[1][0] = "o";
		test[1][1] = "o";
		test[2][1] = "o";
		test[2][2] = "-";
		System.out.println("The winner of test is " + TicTacToe.isGameOver(test));
		Intelligence kuzo = new Intelligence();
		TicTacToe Sam = new TicTacToe();
		Sam.play(kuzo);
		
	}

	public void onMouseClick(double x, double y) {
		// enter code here

	}

	public void keyPress(String s) {
		// enter code here

	}
}
