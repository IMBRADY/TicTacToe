import pkg.*;
import java.util.ArrayList;

public class TicTacToe
{
 private String[][] board = new String[3][3];
 private int movecount = 1;
 private EasyReader er = new EasyReader();
 public TicTacToe()
 { 
  for(int row = 0; row < 3; row ++)
  {
   for(int col = 0; col < 3; col++)
   {
    board[row][col]="-";
	System.out.print(board[row][col]);
   }
   System.out.println();
  }
  System.out.println();
 }
 //Method will take in an intelligence
 public void play(Intelligence i)
 {
  int rows;
  int cols;
  Point aiMove = new Point(6,6);
  String userInput=" ";
  String aiInput=" ";
  boolean satisfied = false;
  int aiR;
  int aiC;
  String p1 = "";
  String p2 = "";
	  if((int)(Math.random()*2)==0)
	  { 
	   p1 = "o";
	   p2 = "x";
	  }
	  else
	  {
	   p1 = "x";
	   p2 = "o";
	  }
	  while(satisfied == false)
	  {
	   System.out.println("Pick a side player");
	   userInput = er.readWord();
	   if(userInput.equals("o"))
	   {
		aiInput = "x";
		satisfied = true;
	   }
	   else if(userInput.equals("x"))
	   {
		aiInput = "o";
		satisfied  = true;
	   }
	  }
	  while(isGameOver(board).equals("still"))
	  {
	   if(movecount%2==0)
	   {
		if(p2.equals(userInput))
		{
			//System.out.println("player's turn and it is o!");
			System.out.println("Pick row");
			rows = er.readInt();
			System.out.println("Pick col");
			cols = er.readInt();
			makeMove(userInput,rows,cols);
			movecount++;
		}
		else
		{
		 //System.out.println("ai's turn and it is x!");
		 if(movecount>3)
	     {
		  aiMove = i.decideMove(board,aiInput,aiInput, new Point(5,5),false);
		 }
		 else
	     {
	      aiMove = i.decideMove(board,aiInput,aiInput, new Point(5,5),false);
		 }
		 makeMove(aiInput,aiMove.getRow(),aiMove.getCol());
		 movecount++;
		}
	   }
	   else
	   {
		if(p1.equals(userInput))
		{
		 //System.out.println("player's turn and it is x!");
		 System.out.println("Pick row");
		 rows = er.readInt();
		 System.out.println("Pick col");
		 cols = er.readInt();
		 makeMove(userInput,rows,cols);
		 movecount++;
		}
		else
		{
		// System.out.println("ai's turn and it is x!");
		  if(movecount>3)
	     {
		  aiMove = i.decideMove(board,aiInput,aiInput, new Point(5,5),false);
		 }
		 else
	     {
	      aiMove = i.decideMove(board,aiInput,aiInput, new Point(5,5),false);
		 }
		 makeMove(aiInput,aiMove.getRow(),aiMove.getCol());
		 movecount++;
		// System.out.println(movecount);
		}
	   }
	  }
	  System.out.println(isGameOver(board));
 }
 public void makeMove(String s, int r, int c)
 {
  int bro;
  String sam = s;
  int call;
  if(board[r][c].equals("-"))
  {
	board[r][c] = s;
	  for(int row = 0; row < 3; row ++)
	  { 
	   for(int col = 0; col < 3;col ++)
	   {
		System.out.print(board[row][col]);
	   }
	   System.out.println();
	  }
	  System.out.println();
  }
  else
  {
   System.out.println("Thanks a lot! Pick another row");
   bro = er.readInt();
   System.out.println("now column!");
   call = er.readInt();
   makeMove(sam, bro, call);
  }
  
 }
 public static String isGameOver(String[][] boar)
 {
  String inQuestion = " ";
  int colcount = 0;
  int dcount1 = 0;
  int dcount2 = 0;
  for(int row = 0; row < 3; row++)
  {
   for(int col = 0; col < 3; col++)
   {
    if(col==0)
    {
     if(boar[row][col].equals("-"))
	 {
      break;
   	 }
     inQuestion = boar[row][col];
	 colcount++;
	}
	else
    {
     if(boar[row][col].equals(inQuestion))
     {
	  colcount++;
	 }
	 else
	 {
	  colcount = 0;
	  inQuestion = " ";
	  break;
	 }
    }
   }
   if(colcount==3)
   {
    return inQuestion;
   }
  }
  int rowcount = 0;
  for(int col = 0; col < 3; col++)
  {
   for(int row = 0; row < 3; row++)
   {
    if(row==0)
    {
     if(boar[row][col].equals("-"))
     {
	  break;
   	 }
	 inQuestion = boar[row][col];
	 rowcount++;
	}
	else
    {
     if(boar[row][col].equals(inQuestion))
	 {
	  rowcount++;
	 }
	 else
     {
	  rowcount = 0;
	  inQuestion = " ";
	 }
	}
   }
    if(rowcount == 3)
	{
	 return inQuestion;
	}
  }
  for(int i = 0; i < 3; i ++)
  {
   if(i == 0)
   {
	if(boar[i][i].equals("-"))
	{
	 break;
	}
    inQuestion = boar[i][i];
	dcount1++;
   }
   else
   {
    if(boar[i][i].equals(inQuestion))
	{
	 dcount1++;
	}
	else
    {
     break;
    }
   }
  }
  if(dcount1==3)
  {
   return inQuestion;
  }
  int sam =2;
  for(int c = 0; c < 3; c ++)
  {
   if(c==0)
   {
	if(boar[c][sam].equals("-"))
    {
     break;
    }
    dcount2++;
	inQuestion = boar[c][sam];
   }
   else
   { 
    if(boar[c][sam].equals(inQuestion))
    {
     dcount2++;
	}
	else
    {
	 break;
	}
   }
   sam--;
  }
  if(dcount2==3)
  {
   return inQuestion;
  }
  int count = 0;
  for(int row = 0; row < 3; row++)
  {
   for(int col = 0; col < 3; col ++)
   {
    if(boar[row][col].equals("-"))
    {
	}
	else
    {
     count++;
	}
   }
  }
  if(count == 9)
  {
   return "draw";
  }
  return "still";
 }
}
