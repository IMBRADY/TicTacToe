package pkg;
public interface InputKeyControl{
    public void keyPress(String es);
}